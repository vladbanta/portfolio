//***************************************************************************\\
//                                                                           \\
//                     2D Game Framework with Win32 GDI                      \\
//                                                                           \\
//---------------------------------------------------------------------------\\


Table Of Contents
-----------------

1. Controls



1. Controls
-----------

Key Controls :

    Escape         - Exit

    Cursor Up      - Move Plane Forward
    Cursor Down    - Move Plane Backward
    Cursor Left    - Strafe Plane Left
    Cursor Right   - Strafe Plane Right
    
Mouse Controls :
    
    Left Button    - Use Mouse Look
